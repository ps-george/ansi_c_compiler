int main()
{
  while(0){}
}

