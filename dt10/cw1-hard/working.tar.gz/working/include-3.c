# 1 "test-data/src/include-3.ci"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 1 "<command-line>" 2
# 1 "test-data/src/include-3.ci"
int x;

# 1 "test-data/src/mini-stdio.h" 1
struct FILE;

int getc();

struct FILE *fopen(const char *, const char *);
# 4 "test-data/src/include-3.ci" 2

int y;

# 1 "test-data/src/mini-stdio.h" 1
struct FILE;

int getc();

struct FILE *fopen(const char *, const char *);
# 7 "test-data/src/include-3.ci" 2
