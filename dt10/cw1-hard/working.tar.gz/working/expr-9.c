
struct x{
  int f;
};


int main()
{

  int x=5, y=8;

  x = x<y;
  x=x==y;
  y=y!=x;
  x=x<=10<=12;
  x=x>=5>10;

}
