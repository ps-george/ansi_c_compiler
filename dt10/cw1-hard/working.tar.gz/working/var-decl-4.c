long int y;
float z;
double a;
char zzz;
unsigned u;
