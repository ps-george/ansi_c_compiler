# 1 "test-data/src/include-0.ci"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 1 "<command-line>" 2
# 1 "test-data/src/include-0.ci"
# 1 "test-data/src/var-decl-1.c" 1
int x;
# 1 "test-data/src/include-0.ci" 2
