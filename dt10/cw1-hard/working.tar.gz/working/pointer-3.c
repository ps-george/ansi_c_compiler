
struct x{
  int f;
};


int main()
{

  struct x tmp;
  struct x*px=&tmp;

  int t=px->f;
  t=tmp.f;

  return t;
}
