struct x { int x
    : 10; };

