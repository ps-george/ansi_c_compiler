int main()
{
  switch(10){
  case 5:
    break;
  default:
    break;
  }
}

