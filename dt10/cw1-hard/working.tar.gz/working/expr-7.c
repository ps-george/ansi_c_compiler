
int main()
{

  int xx=10;

  xx++;
  --xx;
  ++xx;--xx;

}
