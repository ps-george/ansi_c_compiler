const char *x="  X \" 10    ";
