
int f()
{
int x=0 && 0;
int u=5 || x;
 return u;
}
