
int main()
{

  int x=10;
  x += 11;x-=12;x*=13;x/=14;

}
