int main()
{
  for(;;){}
}

