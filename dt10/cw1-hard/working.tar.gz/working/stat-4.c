int main()
{
  do{}while(1);
}

