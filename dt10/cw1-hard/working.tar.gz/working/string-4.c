const char *x="X \n ";
