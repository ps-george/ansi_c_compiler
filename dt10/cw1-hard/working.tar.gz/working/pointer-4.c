
struct x{
  int f;
};


int main()
{

  struct x tmp;
  struct x*px=&tmp;

  int t=sizeof(tmp);
  t=sizeof(*px);

  return t;

}
