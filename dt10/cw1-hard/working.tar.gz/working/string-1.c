const char *x="X";
