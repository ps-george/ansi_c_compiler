const char *x="X Y" "wibble";
